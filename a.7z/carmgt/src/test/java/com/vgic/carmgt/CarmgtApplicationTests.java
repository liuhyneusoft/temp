package com.vgic.carmgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarmgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
