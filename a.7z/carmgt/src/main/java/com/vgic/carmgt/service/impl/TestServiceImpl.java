package com.vgic.carmgt.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;
import com.vgic.carmgt.domain.model.TestResult;
import com.vgic.carmgt.domain.model.TestResult2;
import com.vgic.carmgt.domain.param.TestParam;
import com.vgic.carmgt.mapper.TestMapper;
import com.vgic.carmgt.service.TestService;
import com.vgic.carmgt.util.PaginationUtil;

@Service
public class TestServiceImpl implements TestService {

	@Autowired
	private TestMapper testMapper;

	@Override
	public String test() {
		TestResult reret = testMapper.test("hello word");
		return reret.getName();
	}

	@Override
	public Page<TestResult> getTestList(TestParam param) {
		Page<TestResult> page = PaginationUtil.getPage(param.getPagination());
		testMapper.list(param);
		return page;
	}

	@Override
	public Page<TestResult2> getTestList2(TestParam param) {
		Page<TestResult2> page = PaginationUtil.getPage(param.getPagination());
		testMapper.list2(param);
		return page;
	}

}
