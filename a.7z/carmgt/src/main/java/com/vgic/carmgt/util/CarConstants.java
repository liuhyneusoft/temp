package com.vgic.carmgt.util;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Component
@Getter
public class CarConstants {
	    public final static int MAX_PAGE_SIZE = 50;
	     
}
