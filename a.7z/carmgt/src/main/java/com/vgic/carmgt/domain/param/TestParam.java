package com.vgic.carmgt.domain.param;

import com.vgic.carmgt.domain.page.Pagination;

import lombok.Data;

@Data
public class TestParam {
	  private Pagination pagination;
	  private String name;
}
