package com.vgic.carmgt.domain.response;

public class ErrorResponse extends BaseResponse {
    public ErrorResponse() {
        setCode(ExceptionCode.INTERNAL_SERVER_ERROR.getCode());
        setMessage(ExceptionCode.INTERNAL_SERVER_ERROR.getMessage());
    }
}
