package com.vgic.carmgt.domain.response;

public interface CarmgtResponse extends ResponseCode {
    Object getResult();
}
