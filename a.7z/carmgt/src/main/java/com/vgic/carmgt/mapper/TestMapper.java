package com.vgic.carmgt.mapper;
import org.springframework.stereotype.Repository;
import org.apache.ibatis.annotations.Param;

import com.vgic.carmgt.domain.model.TestResult;
import com.vgic.carmgt.domain.model.TestResult2;
import com.vgic.carmgt.domain.param.TestParam;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
@Repository
@Mapper
public interface TestMapper {
	public TestResult test(@Param("name") String name);
	List<TestResult> list(@Param("params") TestParam param);
	List<TestResult2> list2(@Param("params") TestParam param);
}
