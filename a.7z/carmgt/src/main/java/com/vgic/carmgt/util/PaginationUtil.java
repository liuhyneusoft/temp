package com.vgic.carmgt.util;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.vgic.carmgt.domain.page.Pagination;

public class PaginationUtil<T> {
	public static <T> Page<T> getPage(Pagination pagination) {
		if (pagination == null) {
			return getDefaultPage();
		}
		int startPage = pagination.getPage();
		int pageSize = pagination.getPageSize();
		if (startPage < 1) {
			startPage = 1;
		}
		if (pageSize > CarConstants.MAX_PAGE_SIZE || pageSize < 1) {
			pageSize = CarConstants.MAX_PAGE_SIZE;
		}
		return PageHelper.startPage(startPage, pageSize);
	}

	public static <T> Page<T> getDefaultPage() {
		return new Page<T>(1, CarConstants.MAX_PAGE_SIZE);
	}

	public static <T> Page<T> getPageForEs(Pagination pagination) {
		if (pagination == null) {
			return new Page<T>(1, CarConstants.MAX_PAGE_SIZE);
		}
		int startPage = pagination.getPage() - 1;
		int pageSize = pagination.getPageSize();
		if (startPage < 0) {
			startPage = 0;
		}
		if (pageSize > CarConstants.MAX_PAGE_SIZE) {
			pageSize = CarConstants.MAX_PAGE_SIZE;
		}
		return new Page<T>(startPage, pageSize);
	}

	public static int getOffset(Pagination pagination) {
		if (pagination == null) {
			return 0;
		}
		int startPage = pagination.getPage() - 1;
		int pageSize = pagination.getPageSize();
		if (startPage < 0) {
			startPage = 0;
		}
		if (pageSize > CarConstants.MAX_PAGE_SIZE) {
			pageSize = CarConstants.MAX_PAGE_SIZE;
		}
		return startPage * pageSize;
	}

	public static int getPageSize(Pagination pagination) {
		if (pagination == null) {
			return CarConstants.MAX_PAGE_SIZE;
		}
		int pageSize = pagination.getPageSize();
		if (pageSize > CarConstants.MAX_PAGE_SIZE) {
			pageSize = CarConstants.MAX_PAGE_SIZE;
		}
		return pageSize;
	}
}
