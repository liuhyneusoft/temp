package com.vgic.carmgt.domain.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.github.pagehelper.Page;
import com.vgic.carmgt.domain.page.Pagination;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseResponse implements CarmgtResponse {
    protected int code;
    protected String message;
    protected Object result;
    protected Pagination pagination;
    protected long version;

    public static BaseResponse of(Page<? extends Object> page) {
        BaseResponse response = new BaseResponse();
        response.setResult(page.getResult());
        response.pagination = new Pagination(page.getPageSize(), page.getPageNum(), page.getTotal());
        return response;
    }
}

