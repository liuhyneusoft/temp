package com.vgic.carmgt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vgic.carmgt.domain.model.TestResult;
import com.vgic.carmgt.domain.model.TestResult2;
import com.vgic.carmgt.domain.page.Pagination;
import com.vgic.carmgt.domain.param.TestParam;
import com.vgic.carmgt.domain.response.BaseResponse;
import com.vgic.carmgt.domain.response.SuccessResponse;
import com.vgic.carmgt.service.TestService;

@RestController
@RequestMapping("/test")
public class TestController {
	@Autowired
	private TestService testService;

	@RequestMapping(value = "/hw", method = { RequestMethod.POST, RequestMethod.GET })
	public String aa() {
		return "****" + testService.test();
	}

	@RequestMapping(value = "/list1", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView index1(ModelAndView mav) {
		mav.setViewName("test/test1");
		TestParam param = new TestParam();
		Pagination p = new Pagination();
		p.setPage(1);
		param.setPagination(p);
		Page<TestResult> testList = testService.getTestList(param);
		mav.addObject("rets",testList.getResult());

	    
		return mav;
	}

	@RequestMapping(value = "/list2", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView index2(ModelAndView mav) {
		TestParam param = new TestParam();
		Pagination p = new Pagination();
		p.setPage(2);
		param.setPagination(p);
		Page<TestResult> list = testService.getTestList(param);
		
		PageHelper.startPage(2,20);
		PageInfo<TestResult> pageInfo = new PageInfo<TestResult>(list.getResult(),20);
		
		
		mav.addObject("pageInfo", pageInfo);
		mav.setViewName("test/test2");
		return mav;
	}

	@RequestMapping(value = "/list3", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView index3(ModelAndView mav) {
		mav.setViewName("test/test3");
		return mav;
	}

	@RequestMapping(value = "/page", method = RequestMethod.POST)
	public BaseResponse getBanner(@RequestBody TestParam param) {
		Page<TestResult> testList = testService.getTestList(param);
		return SuccessResponse.of(testList);
	}

	@RequestMapping(value = "/page2", method = RequestMethod.POST)
	public BaseResponse getBanner2(@RequestBody TestParam param) {
		Page<TestResult2> testList = testService.getTestList2(param);
		return SuccessResponse.of(testList);
	}
}
