package com.vgic.carmgt.domain.response;

public interface ResponseCode {
    int getCode();
    String getMessage();
}

