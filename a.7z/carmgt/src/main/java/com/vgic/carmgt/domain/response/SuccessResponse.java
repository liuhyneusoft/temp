package com.vgic.carmgt.domain.response;
import com.github.pagehelper.Page;
import com.vgic.carmgt.domain.page.Pagination;

public class SuccessResponse extends BaseResponse {

    public SuccessResponse() {
        setCode(ExceptionCode.SUCCESS.getCode());
        setMessage(ExceptionCode.SUCCESS.getMessage());
    }

    public static SuccessResponse withMessage(String message) {
        SuccessResponse response = new SuccessResponse();
        response.setMessage(message);
        return response;
    }

    public static SuccessResponse of(Page<? extends Object> page) {
        SuccessResponse response = new SuccessResponse();
        response.setResult(page.getResult());
        response.setPagination(new Pagination(page.getPageNum(), page.getPageSize(), page.getTotal()));
        return response;
    }

    public static SuccessResponse of(Object result) {
        SuccessResponse response = new SuccessResponse();
        response.setResult(result);
        return response;
    }
}
