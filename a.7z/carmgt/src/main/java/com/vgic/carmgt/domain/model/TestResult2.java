package com.vgic.carmgt.domain.model;

import lombok.Data;

 @Data
public class TestResult2 {

	private String name;

 
	
}
