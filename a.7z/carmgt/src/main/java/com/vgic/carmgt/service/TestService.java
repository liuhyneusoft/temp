package com.vgic.carmgt.service;

import com.github.pagehelper.Page;
import com.vgic.carmgt.domain.model.TestResult;
import com.vgic.carmgt.domain.model.TestResult2;
import com.vgic.carmgt.domain.param.TestParam;

public interface TestService {

	public String test();

	public Page<TestResult> getTestList(TestParam param);

	public Page<TestResult2> getTestList2(TestParam param);
}
