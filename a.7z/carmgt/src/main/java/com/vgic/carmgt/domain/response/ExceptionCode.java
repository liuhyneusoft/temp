package com.vgic.carmgt.domain.response;


public enum ExceptionCode implements ResponseCode {
    SUCCESS(200, "SUCCESS"),
    BAD_REQUEST(400, "BAD_REQUEST"),
    INVALID_ARGUMENT(400, "INVALID_ARGUMENT"),
    LIMIT_EXCEED(400, "LIMIT_EXCEED"),
    ALREADY_PROCESSED(400, "ALREADY_PROCESSED"),
    UNAUTHORIZED(401, "AUTHENTICATION_ERROR"),
    FORBIDDEN(403, "FORBIDDEN"),
    RATE_LIMIT_EXCEED(403, "RATE_LIMIT_EXCEED"),
    NOT_FOUND(404, "NOT_FOUND"),
    LIMITED_COUNTRY(404, "Access not allowed."),
    METHOD_NOT_ALLOWED(405, "Method Not Allowed"),
    INTERNAL_SERVER_ERROR(500, "INTERNAL_SERVER_ERROR");

    private final int code;
    private final String message;

    private ExceptionCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }

}
